package com.placement.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.placement.Service.CollegeService;
import com.placement.college.College;
@RestController
public class Controller {

	@Autowired
	CollegeService cs;
	
	@PostMapping("/addCollege")
	public void addCollege(@RequestBody College c)
	{
		cs.addCollege(c);
	}
	
	@GetMapping("/getCollege/{id}")
	public College getCollege(@PathVariable int id)
	{
		return cs.getCollege(id);
	}
	
	@PutMapping("/updateCollege")
	public College updateCollege(@RequestBody College c)
	{
		return cs.updateCollege(c);
	}
	
	@DeleteMapping("/deleteCollege/{id}")
	public void deleteCollege(@PathVariable int id)
	{
		cs.deleteCollege(id);
	}
}
