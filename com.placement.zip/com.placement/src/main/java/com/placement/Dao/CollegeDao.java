package com.placement.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.placement.college.College;

public interface CollegeDao extends JpaRepository<College, Integer>{

}
