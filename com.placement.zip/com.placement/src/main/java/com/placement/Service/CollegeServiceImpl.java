package com.placement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.Dao.CollegeDao;
import com.placement.college.College;
@Service
public class CollegeServiceImpl implements CollegeService{

	@Autowired
	CollegeDao cd;
	
	@Override
	public void addCollege(College c) {
		cd.save(c);
	}

	@Override
	public College getCollege(int id) {
		return cd.findById(id).get();
		
	}

	@Override
	public void deleteCollege(int id) {
		College s=cd.findById(id).get();
		cd.delete(s);
		
	}

	@Override
	public College updateCollege(College c) {
		cd.save(c);
		return c;
	}

}
