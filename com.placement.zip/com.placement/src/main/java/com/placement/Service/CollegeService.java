package com.placement.Service;

import com.placement.college.College;

public interface CollegeService {
	
	public void addCollege(College c);

	public College getCollege(int id);
	
	public void deleteCollege(int id);

	public College updateCollege(College c);
}
